from django.contrib import admin
from society.models import Flat, Society
# Register your models here.

admin.site.register(Society)
admin.site.register(Flat)
